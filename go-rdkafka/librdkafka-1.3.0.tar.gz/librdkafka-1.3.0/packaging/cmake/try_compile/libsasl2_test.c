#include <string.h>
#include <sasl/sasl.h>

int main() {
        sasl_done();
        return 0;
}
